---
name: "\U00002B50 Submit a feature request"
about: Request a feature that you think should be supported

---

### Describe the feature you'd like supported

A description of what the feature is.

### Proposed solution

What are the benefits/reasons for having this feature?

### Additional context

Add any other context that might be helpful, if applicable.
