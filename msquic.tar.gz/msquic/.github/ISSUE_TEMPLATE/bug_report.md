---
name: "\U0001F41B Bug report"
about: Report a bug or unexpected behavior

---

### Describe the bug

A description of what the bug is.

### Steps to reproduce the behavior

1. Run X
2. View output
3. See error

### Expected vs actual behavior

A description of what you expected to happen and what actually happened.
