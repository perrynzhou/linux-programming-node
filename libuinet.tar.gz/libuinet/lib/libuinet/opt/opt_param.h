#define HZ 100
