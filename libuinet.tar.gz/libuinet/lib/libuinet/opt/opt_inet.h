#define INET 1
#define INET_NO_CC_UNLOAD 1
#define INET_NO_TCP_KHELP 1
#define INET_COPY 1
