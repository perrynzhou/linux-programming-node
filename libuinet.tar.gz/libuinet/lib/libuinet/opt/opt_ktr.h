//#define KTR 0
//#define KTR_COMPILE KTR_xxx
//#define KTR_VERBOSE 2
