#ifndef	__UINET_IF_SPAN_H__
#define	__UINET_IF_SPAN_H__

extern	int if_span_attach(struct uinet_if *uif);
extern	int if_span_detach(struct uinet_if *uif);

#endif	/* __UINET_IF_SPAN_H__ */
