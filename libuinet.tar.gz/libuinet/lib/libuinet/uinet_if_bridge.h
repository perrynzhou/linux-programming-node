#ifndef	__UINET_IF_BRIDGE_H__
#define	__UINET_IF_BRIDGE_H__

extern	int if_bridge_attach(struct uinet_if *uif);
extern	int if_bridge_detach(struct uinet_if *uif);

#endif	/* __UINET_IF_BRIDGE_H__ */
