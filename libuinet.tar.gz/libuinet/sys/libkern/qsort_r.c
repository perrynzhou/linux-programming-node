/*-
 * This file is in the public domain.  Originally written by Garrett
 * A. Wollman.
 *
 * $FreeBSD: release/9.1.0/sys/libkern/qsort_r.c 139815 2005-01-07 00:24:33Z imp $
 */
#define I_AM_QSORT_R
#include "libkern/qsort.c"
