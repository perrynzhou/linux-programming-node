/*	$FreeBSD: release/9.1.0/sys/netinet6/icmp6.h 62587 2000-07-04 16:35:15Z itojun $	*/
/*	$KAME: icmp6.h,v 1.17 2000/06/11 17:23:40 jinmei Exp $	*/

#error "netinet6/icmp6.h is obsolete.  use netinet/icmp6.h"
